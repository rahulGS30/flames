# FLAMES Game

A fun React-based game to determine your relationship using the FLAMES logic.