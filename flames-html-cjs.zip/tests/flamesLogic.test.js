const { getFlamesResult } = require('../src/flamesLogic');

test('FLAMES logic test 1', () => {
  expect(getFlamesResult('Alice', 'Bob')).toBe('Friends');
});

test('FLAMES logic test 2', () => {
  expect(getFlamesResult('John', 'Jane')).toBe('Enemies');
});
