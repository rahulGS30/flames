import React, { useState } from 'react';

function flamesResult(name1, name2) {
  let str1 = name1.toLowerCase().replace(/\s/g, '');
  let str2 = name2.toLowerCase().replace(/\s/g, '');
  let common = '';

  for (let char of str1) {
    if (str2.includes(char)) {
      str2 = str2.replace(char, '');
      common += char;
    }
  }

  let count = str1.length + str2.length - 2 * common.length;
  const flames = ['Friends', 'Love', 'Affection', 'Marriage', 'Enemies', 'Siblings'];
  let index = 0;

  while (flames.length > 1) {
    index = (index + count - 1) % flames.length;
    flames.splice(index, 1);
  }

  return flames[0];
}

function App() {
  const [name1, setName1] = useState('');
  const [name2, setName2] = useState('');
  const [result, setResult] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (name1 && name2) {
      setResult(flamesResult(name1, name2));
    }
  };

  return (
    <div className="min-h-screen bg-pink-50 flex items-center justify-center">
      <div className="bg-white p-8 rounded-2xl shadow-lg max-w-md w-full text-center">
        <h1 className="text-3xl font-bold text-pink-600 mb-6">FLAMES Game 💖</h1>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Enter First Name"
            value={name1}
            onChange={(e) => setName1(e.target.value)}
            className="w-full mb-4 p-2 border border-pink-300 rounded-lg"
            required
          />
          <input
            type="text"
            placeholder="Enter Second Name"
            value={name2}
            onChange={(e) => setName2(e.target.value)}
            className="w-full mb-4 p-2 border border-pink-300 rounded-lg"
            required
          />
          <button
            type="submit"
            className="bg-pink-500 text-white px-4 py-2 rounded-lg hover:bg-pink-600 w-full"
          >
            Calculate 🔥
          </button>
        </form>
        {result && (
          <div className="mt-6 text-lg text-pink-700">
            Relationship Status: <strong>{result}</strong>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;