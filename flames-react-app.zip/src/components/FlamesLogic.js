export function calculateFlamesResult(name1, name2) {
  let n1 = name1.toLowerCase().replace(/ /g, '');
  let n2 = name2.toLowerCase().replace(/ /g, '');
  let name1Arr = n1.split('');
  let name2Arr = n2.split('');

  for (let i = 0; i < name1Arr.length; i++) {
    const index = name2Arr.indexOf(name1Arr[i]);
    if (index !== -1) {
      name1Arr.splice(i, 1);
      name2Arr.splice(index, 1);
      i--;
    }
  }

  const count = name1Arr.length + name2Arr.length;
  const flames = ['Friends', 'Love', 'Affection', 'Marriage', 'Enemies', 'Siblings'];
  let index = 0;
  for (let i = 0; flames.length > 1; i++) {
    index = (count % flames.length) - 1;
    if (index >= 0) {
      flames.splice(index, 1);
    } else {
      flames.pop();
    }
  }

  return flames[0];
}