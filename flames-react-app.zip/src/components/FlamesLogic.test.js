import { calculateFlamesResult } from './FlamesLogic';

test('FLAMES result for Alice and Bob', () => {
  expect(calculateFlamesResult('Alice', 'Bob')).toBe('Friends');
});

test('FLAMES result for John and Jane', () => {
  expect(calculateFlamesResult('John', 'Jane')).toBe('Enemies');
});

test('FLAMES result for Sam and Samantha', () => {
  expect(calculateFlamesResult('Sam', 'Samantha')).toBe('Affection');
});