function getFlamesResult(name1, name2) {
  let str1 = name1.replace(/\s/g, '').toLowerCase();
  let str2 = name2.replace(/\s/g, '').toLowerCase();

  for (let char of str1) {
    if (str2.includes(char)) {
      str1 = str1.replace(char, '');
      str2 = str2.replace(char, '');
    }
  }

  let count = str1.length + str2.length;
  const flames = ['Friends', 'Love', 'Affection', 'Marriage', 'Enemies', 'Siblings'];
  let index = 0;

  while (flames.length > 1) {
    index = (index + count - 1) % flames.length;
    flames.splice(index, 1);
  }

  return flames[0];
}

module.exports = { getFlamesResult };
