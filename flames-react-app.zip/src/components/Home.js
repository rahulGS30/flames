import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Home() {
  const [name1, setName1] = useState('');
  const [name2, setName2] = useState('');
  const navigate = useNavigate();

  const calculateFlames = () => {
    let n1 = name1.toLowerCase().replace(/ /g, '');
    let n2 = name2.toLowerCase().replace(/ /g, '');
    let name1Arr = n1.split('');
    let name2Arr = n2.split('');

    for (let i = 0; i < name1Arr.length; i++) {
      const index = name2Arr.indexOf(name1Arr[i]);
      if (index !== -1) {
        name1Arr.splice(i, 1);
        name2Arr.splice(index, 1);
        i--;
      }
    }

    const count = name1Arr.length + name2Arr.length;
    const flames = ['Friends', 'Love', 'Affection', 'Marriage', 'Enemies', 'Siblings'];
    let index = 0;
    for (let i = 0; flames.length > 1; i++) {
      index = (count % flames.length) - 1;
      if (index >= 0) {
        flames.splice(index, 1);
      } else {
        flames.pop();
      }
    }

    navigate('/result', { state: { result: flames[0] } });
  };

  return (
    <div className="container">
      <h1>FLAMES Game</h1>
      <input type="text" placeholder="Enter first name" value={name1} onChange={e => setName1(e.target.value)} />
      <input type="text" placeholder="Enter second name" value={name2} onChange={e => setName2(e.target.value)} />
      <button onClick={calculateFlames}>Calculate</button>
    </div>
  );
}

export default Home;