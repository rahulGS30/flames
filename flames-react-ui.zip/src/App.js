import React, { useState } from 'react';
import './App.css';

function App() {
  const [name1, setName1] = useState('');
  const [name2, setName2] = useState('');
  const [result, setResult] = useState('');
  const [showResult, setShowResult] = useState(false);

  const calculateFlames = () => {
    let n1 = name1.toLowerCase().replace(/ /g, '');
    let n2 = name2.toLowerCase().replace(/ /g, '');
    let name1Arr = n1.split('');
    let name2Arr = n2.split('');

    for (let i = 0; i < name1Arr.length; i++) {
      const index = name2Arr.indexOf(name1Arr[i]);
      if (index !== -1) {
        name1Arr.splice(i, 1);
        name2Arr.splice(index, 1);
        i--;
      }
    }

    const count = name1Arr.length + name2Arr.length;
    const flames = ['Friends', 'Love', 'Affection', 'Marriage', 'Enemies', 'Siblings'];
    let index = 0;
    while (flames.length > 1) {
      index = (count % flames.length) - 1;
      if (index >= 0) {
        flames.splice(index, 1);
      } else {
        flames.pop();
      }
    }

    setResult(flames[0]);
    setShowResult(true);
  };

  const resetForm = () => {
    setName1('');
    setName2('');
    setResult('');
    setShowResult(false);
  };

  return (
    <div className="container">
      <h1>FLAMES Game</h1>
      <input
        type="text"
        placeholder="Enter first name"
        value={name1}
        onChange={(e) => setName1(e.target.value)}
      />
      <input
        type="text"
        placeholder="Enter second name"
        value={name2}
        onChange={(e) => setName2(e.target.value)}
      />
      <div className="buttons">
        <button onClick={calculateFlames}>Calculate</button>
        <button onClick={resetForm}>Reset</button>
      </div>
      {showResult && <p className="result">Relationship: <strong>{result}</strong></p>}
    </div>
  );
}

export default App;