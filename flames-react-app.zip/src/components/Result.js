import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

function Result() {
  const { state } = useLocation();
  const navigate = useNavigate();

  return (
    <div className="container">
      <h1>FLAMES Result</h1>
      <h2>{state?.result || 'No result'}</h2>
      <button onClick={() => navigate('/')}>Try Again</button>
    </div>
  );
}

export default Result;